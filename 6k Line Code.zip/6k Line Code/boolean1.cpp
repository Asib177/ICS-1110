/*#include<stdio.h>
int main()
{
   int a;
   scanf("%d",&a);
   (a%2==0)? (printf("%d is a Even",a)) : (printf("%d is a Odd",a));
   return 0;
}*/

#include <stdio.h>

int main()
{
   int a;
   scanf("%d", &a);
   (a % 2 == 0) ? (printf("%d is even", a)) : (printf("%d is odd", a));

   return 0;
}
