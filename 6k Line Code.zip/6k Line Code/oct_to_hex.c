#include <stdbool.h>

int main()
{
    int n;
    printf("Enter Octal Number: ");
    scanf("%o", &n);

    printf("Hexadecimal Number is: %x", n);

    return 0;
}