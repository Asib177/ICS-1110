#include <stdbool.h>

int main()
{
    int n;
    printf("Enter Decimal Number: ");
    scanf("%d", &n);

    printf("Hexadecimal Number is: %x", n);

    return 0;
}