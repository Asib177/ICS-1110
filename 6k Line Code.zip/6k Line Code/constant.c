#include <stdio.h>
float pi = 3.1416;

int main()
{
    // int a=3;
    int a;
    float b;
    printf("%f", pi);

    return 0;
}