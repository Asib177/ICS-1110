#include <stdio.h>

int main()
{
    int digit, sum = 0, n, x = 0, i = 0;

    int arr[2];
    scanf("%d", &n);
    while (n != 0)
    {
        digit = n % 2;
        n = n / 2;
arri
i++;
    }

    printf("%d", x);
    return 0;
}