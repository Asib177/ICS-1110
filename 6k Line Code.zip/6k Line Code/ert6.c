#include <stdio.h>
void input()
{
    printf("This is a Function");
}

int main()
{
    input();

    return 0;
}