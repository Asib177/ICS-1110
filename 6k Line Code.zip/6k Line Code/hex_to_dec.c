#include <stdbool.h>

int main()
{
    int n;
    printf("Enter Hexadecimal Number: ");
    scanf("%x", &n);

    printf("Decimal Number is: %d", n);

    return 0;
}