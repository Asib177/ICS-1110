#include <stdio.h>

int main()
{
    int n;
    scanf("%d", &n);

    int result = n * n;
    printf("Squre is: %d", result);

    return 0;
}