#include <stdio.h>
#include <conio.h>

void clrscr(void);
int main()
{
    void clrscr();
    printf("Hello World");
    return 0;
}