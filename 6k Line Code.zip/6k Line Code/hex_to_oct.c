#include <stdbool.h>

int main()
{
    int n;
    printf("Enter Hexadecimal Number: ");
    scanf("%x", &n);

    printf("Octal Number is: %o", n);

    return 0;
}