#include <stdio.h>

int main()
{
    printf("\"\\n/\\Hello\nWorld/\\n\"");
    return 0;
}